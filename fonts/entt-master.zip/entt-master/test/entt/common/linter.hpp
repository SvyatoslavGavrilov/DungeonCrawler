#ifndef ENTT_COMMON_LINTER_HPP
#define ENTT_COMMON_LINTER_HPP

namespace test {

template<typename Type>
void is_initialized(Type &) {}

} // namespace test

#endif
